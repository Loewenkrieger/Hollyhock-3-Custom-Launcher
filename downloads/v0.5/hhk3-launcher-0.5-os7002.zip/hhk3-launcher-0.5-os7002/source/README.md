# Hollyhock 3 Custom Launcher

Ein klassischer Launcher für **HH3-Apps (`.hh3`)** auf dem Casio ClassPad II. Mit übersichtlicher App-Auswahl, Programminfos und Bedienung per Touch oder Tasten.

**Version 0.5** · Für bereits installiertes Hollyhock 3 auf **OS 02.01.7002.0001**.

## Installation

[run.bin herunterladen](../run.bin)

1. Die bisherige `run.bin` sichern.
2. Die neue `run.bin` und deine `.hh3`-Apps ins Hauptverzeichnis des Taschenrechner-Laufwerks kopieren.
3. Sicher auswerfen, USB trennen und den Launcher über das System-Menü öffnen.

Ein Firmwareupdate ist dafür nicht nötig.

## Bedienung

App im Dropdown auswählen und mit **Run** starten. **Close**, **X** oder **Clear** schließen den Launcher. Mit den Pfeiltasten und **EXE** geht es auch ohne Touch.

Die fünf zuletzt gestarteten Apps stehen mit einem **\*** oben in der Liste. Die letzte App ist direkt ausgewählt – zum erneuten Starten genügt **EXE**. Der Verlauf bleibt beim nächsten Öffnen erhalten.

![Vorschau der Oberfläche](docs/preview/classic-closed.png)

Die Version wurde automatisiert geprüft; der abschließende Test am echten ClassPad steht noch aus.

[Ausführliche Anleitung](docs/README_DE.md) · [Build und Tests](docs/BUILD.md) · [Prüfbericht](docs/TEST-REPORT.txt)

Basierend auf [YAL](https://github.com/ClasspadDev/yal) und dem [Hollyhock-3-SDK](https://github.com/ClasspadDev/hollyhock-3).
